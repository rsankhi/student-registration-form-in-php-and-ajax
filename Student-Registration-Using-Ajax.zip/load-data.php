<?php
$con=mysqli_connect('localhost','root','','ajx_reg_student');
if(isset($_POST['country_data'])){
if(isset($_POST['fdata'])==""){
  $country="";
$qry="select * from country";
$run=mysqli_query($con,$qry);
if($run==true){
    
    while($result=mysqli_fetch_array($run)){
        $cid=$result['c_id'];
        $cname=$result['name'];
        
        $country.="<option value='$cid'>$cname</option>";
    }
    
}
    echo $country;
}
elseif($_POST['fdata']=="stateData"){
    $country="";
$qry="SELECT * FROM state WHERE c_id={$_POST['id']}";
$run=mysqli_query($con,$qry);
if($run==true){
    
    while($result=mysqli_fetch_array($run)){
        $sid=$result['s_id'];
        $sname=$result['name'];
        
        $country.="<option value='$sid'>$sname</option>";
    }
    
}
    echo $country;
}
}
else{
    //$file=$_FILES['image']['temp_name'];
     $name = $_POST['name'];
     $fname = $_POST['fname'];
     $country = $_POST['country'];
     $state = $_POST['state'];
     $address = $_POST['address'];
     $file= $_FILES['image']; 
    $file_name = $file['name'];
    $file_tname = $file['tmp_name'];
    
    $file_extension= pathinfo($file_name,PATHINFO_EXTENSION);
    $spt_extension= array("jpg","png","jpeg");
    
    if(in_array($file_extension,$spt_extension )){
        $new_name= rand().".".$file_extension;
        $path="user-image/".$new_name;
        
        $reg_qry="INSERT INTO `student`(`name`, `fname`, `country`, `state`, `address`, `image`) VALUES ('$name','$fname','$country','$state','$address','$new_name')";
        $run_reg_qry=mysqli_query($con,$reg_qry)     ;
        if(move_uploaded_file($file_tname,$path) && $run_reg_qry ){
            echo"Congratulation !! Registration Complate";
        }
        
        
    }
    else{
        echo"<p style='color:red;font-size:11px'>Please Select Only jpg/jpeg/png file</p>";
    }
}


 




?>