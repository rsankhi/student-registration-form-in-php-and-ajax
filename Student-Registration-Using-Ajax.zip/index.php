<!Doctype html>
<html>
    <head>
        <meta charset="utf-8">
   <meta name="viewport" content="width=device-width, initial-scale=1">
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
        
        <style>
            *{
                font-family: sans-serif;
            }
            .account-create-div{
                width: 330px;
                padding: 15px;
                position: relative;
                top: 0;
                left: 50%;
                transform: translate(-50%,0)
                
            }
            label{
                font-size: 10px;
                color: #0e0e55;
                font-weight: 600;
            }
            .input-box{
                padding: 10px;
                margin: 10px;
                
            }
            .input-box input{
                padding: 10px;
                width: 90%;
            } 
            .input-box button
            {
                padding: 10px;
                width: 100%;
            }
            .input-box select{
                padding: 10px;
                width: 100%;
            }
        </style>
    
    
    </head>
    <body>
       <div class="main"> <!---- Main Div Open -->
            <div class="account-create-div"><!-- account-create-div Open --->
                <form id="register_form" ><!---- Form Open -->
                    <fieldset><br> <h3>Student Registration </h3>
                        <p style="font-size:12px;color:green;font-weight:bold"  id="msg"></p>
                        <hr>
                         <div class="input-box">
                        <label>Name</label>
                        <input type="text" id="name" name="name" placeholder="Rahul " autocomplete="no" required>
                    </div>
                        <div class="input-box">
                        <label>Fname</label>
                        <input type="text" id="fname" name="fname" placeholder="Aman" autocomplete="no" required>
                        
                        </div>
                         <div class="input-box">
                             <label>Country</label>
                           <select name="country" id="country" required>
                             <option>select country</option>
                             </select>  
                        </div>
                        <div class="input-box">
                            <label>State</label>
                           <select name="state" id="state" required >
                             <option>select state</option>
                             </select>  
                        </div>
                        
                         <div class="input-box">
                        <label>Address</label>
                        <textarea cols="35" rows="8" name="address"  required></textarea>
                        
                        </div>
                        <div class="input-box">
                            <label>Photograph (jpg/jpeg/png)</label> 
                            <input type="file" id="file" name="image" required>
                        </div>
                       
                         <div class="input-box">
                             <button type="reset" name="Login" value="Login Now"> Reset</button>
                             <br> <br>
                             <button type="submit" id="register_btn" name="register" value="true" > Register</button> 
                        </div>
                        <hr>
                        <center><p style="font-size:12px;color:green;font-weight:bold" id="msg1"></p> <p style="font-size:10px">Simple Registration Form </p></center>
                    </fieldset> 
                </form><!---- Form Close -->
           </div><!----account-create-div Close -->
            
        </div><!---- Main Div Close -->
        
        
    </body>
    <!-- jQuery library -->

    
    <script type="text/javascript">
        $(document).ready(function(){
           function loadData(type,category_id) {
               $.ajax({
                   
                   url:"load-data.php" ,
                   type: "POST",
                   data:{fdata:type,id:category_id,country_data:''},
                   success: function(data){
                   if(type=="stateData"){
                   $("#state").html(data);
                       var state = data;
                    }    
                      else{
                      $("#country").append(data);
                          
                      }
                    
                       
                   }
               });
           }
             loadData() ;
            
            // state record load 
            
            $("#country").on("change",function(){
                var country = $("#country").val();
               
                loadData("stateData",country)
               
               
            });
            
            
            // submit data 
            
            $("#register_form").on("submit",function(e){
                e.preventDefault();
                var submit_data= $("#register_btn").val();
                var name   = $("#name").val();
                var fname   = $("#fname").val();
                var country = $("#country").val();
                var state   = $("#state").val();
                var address = $("#address").val();               
                var file = $("#file").val();
               
                //pass all information in one variable
                var formData = new FormData(this);
                
                if(country !=""&& name !=""&& fname !="" && state !=""){

                
                
                $.ajax({
                  
                    url:"load-data.php",
                    type:"POST" ,
                    data:formData,
                    contentType: false, //multipart/form-data
                    processData : false,
                    success: function(data){
                     $("#msg").html(data);
                     $("#msg1").html(data);
                    }
                    
                });
                 
                }else{
                    alert("Empty Form Feild");
                }    
            });
           
            
        });
    
    </script>

</html>
